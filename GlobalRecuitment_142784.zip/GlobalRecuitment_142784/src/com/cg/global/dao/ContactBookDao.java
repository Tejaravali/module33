package com.cg.global.dao;

import java.util.ArrayList;

import com.cg.global.bean.EnquiryBean;
import com.cg.global.exception.ContactBookException;


public interface ContactBookDao 
{
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException;
	public ArrayList<EnquiryBean> getEnquiryDetails() throws ContactBookException;
    public int generateEnquiryId() throws ContactBookException;
}
