package com.cg.groapp.ui;

import java.util.Scanner;

import com.cg.groapp.bean.Enquiry;
import com.cg.groapp.exception.EnquiryException;
import com.cg.groapp.service.*;

public class EnquiryClient 
{
	static Scanner sc=null;
	static EnquiryService esi=null;
	static Enquiry enq=new Enquiry();
	public static void main(String[] args) 
	{
		esi=new EnquiryServiceImpl();
		sc=new Scanner(System.in);
		int choice=0;
		System.out.println("**************************Global Recruitments**************************");
		while(true)
		{
			System.out.println("Choose an operation");
			System.out.println("1.Enter Enquiry Details \n2.View Enquiry Details on Id\n0.Exit");
			System.out.println("*******************************");
			System.out.println("Please enter a choice: ");
			choice=sc.nextInt();
			System.out.println("*****************************************");
			switch(choice)
			{
			case 1:
				enterEnquiries();
				break;
			case 2:
				viewEnquiries();
				break;
			case 0:
				System.out.println("Thank you for selecting us!!");
				System.exit(0);
			}
		}
	}
	
	public static void enterEnquiries() 
	{
		System.out.println("Enter First Name :");
		String fname=sc.next();
		System.out.println("Enter Last Name :");
		String lname=sc.next();
		System.out.println("Enter Contact Number :");
		Long contact=sc.nextLong();
		System.out.println("Enter Preferred Domain :");
		String domain=sc.next();
		System.out.println("Enter Preferred Location :");
		String location=sc.next();
		int data,dataAdded=0,uniqueId=0;
		System.out.println("*****************************************");
		try 
		{
			enq.setFirstName(fname);
			enq.setLastName(lname);
			enq.setContactNo(contact);
			enq.setDomain(domain);
			enq.setCity(location);
						
			if(esi.isValidEnquiry(enq))
			{
				data= esi.addEnquiry(enq);
				uniqueId=data-1;
				dataAdded=data-uniqueId;	
			}
			if(dataAdded==1)
			{
				System.out.println("Thank you "+fname+" "+lname+" your Unique Id is "+uniqueId+" we will contact you shortly.");
			}
			else
			{
				System.out.println("Some exception may be encountered while insertion");
			}
			System.out.println("*****************************************");
		} 
		catch (EnquiryException e) 
		{
			System.out.println(e.getMessage());
		}
	}
	
	public static void viewEnquiries() 
	{
		System.out.println("Enter the Enquiry No. : ");
		int enqId=sc.nextInt();
		System.out.println("*****************************************");
		try
		{
			enq=esi.getEnquiryDetails(enqId);
			System.out.println("Id\tFirst Name\t   Last Name\tContact No.\tPreferred Domain\tPreferred Location");
			System.out.println(enq.getEnquiryId()+"\t"+enq.getFirstName()+"\t"+enq.getLastName()+"\t"+enq.getContactNo()+"\t"+enq.getDomain()+"\t"+enq.getCity());
		}
		catch (EnquiryException e)
		{
			System.out.println(e.getMessage());
		}
		System.out.println("*****************************************");
	}
}