package com.cg.groapp.exception;

public class EnquiryException extends Exception
{
	public EnquiryException(String msg)
	{
		super(msg);
	}
}
