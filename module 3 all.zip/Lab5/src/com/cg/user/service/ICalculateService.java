package com.cg.user.service;

import com.cg.user.dto.Bill;
import com.cg.user.exception.BillException;

public interface ICalculateService {
	public int addBillDetails(Bill bill) throws BillException;
	public String getCustomerName(long consumerNo) throws BillException;
	public boolean validateCustomerId(long cId) throws BillException;
	public boolean validateMeterReading(float lMonReading,float cMonReading) throws BillException;
}
