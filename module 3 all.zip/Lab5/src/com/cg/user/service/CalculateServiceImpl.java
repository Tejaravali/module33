package com.cg.user.service;

import java.util.ArrayList;

import com.cg.user.dao.*;
import com.cg.user.dto.Bill;
import com.cg.user.exception.BillException;

public class CalculateServiceImpl implements ICalculateService
{
	ICalculateDao calDao=null;
	
	public CalculateServiceImpl() 
	{
		calDao=new CalculateDaoImpl();
	}

	@Override
	public int addBillDetails(Bill bill) throws BillException {
		return calDao.addBillDetails(bill);
	}

	@Override
	public String getCustomerName(long consumerNo) throws BillException {
		return calDao.getCustomerName(consumerNo);
	}

	@Override
	public boolean validateCustomerId(long cId) throws BillException {
		ArrayList<Long> conId=new ArrayList<Long>();
		conId=calDao.getCustomerId();
		int flag=0;
		for(Long i:conId)
			{
				if(cId==i)
				{
					flag=1;
				}
			}
		if(flag==1)
		{
			return true;
		}
		else
		{
			throw new BillException("Invalid Consumer Number.Please check it.");
		}
	}

	@Override
	public boolean validateMeterReading(float lMonReading, float cMonReading)
			throws BillException 
	{
		if(cMonReading>lMonReading)
		{
			return true;
		}
		else
		{
			throw new BillException("Current Month Reading should be greater than"
					+ " last Month Reading");
		}
		
	}
}
