package com.cg.user.ui;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.user.dto.*;
import com.cg.user.exception.BillException;
import com.cg.user.service.*;

@WebServlet("/DisplayServlet")
public class DisplayServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	RequestDispatcher rd=null;
    ICalculateService calcServ=null;
    int dataAdded=0;
    public DisplayServlet() {
        super();
       
    }

	public void init(ServletConfig config) throws ServletException {
	
	}

	public void destroy() {
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException,NumberFormatException
	{
		PrintWriter out=response.getWriter();
		RequestDispatcher rd=null;
		calcServ=new CalculateServiceImpl();
		HttpSession session=request.getSession(true);
		long consNo=(Long) session.getAttribute("ConsumerNo");
		
		float units=(Float) session.getAttribute("Units");
		float net=(Float) session.getAttribute("NetAmt");
		try
		{
			String cname=calcServ.getCustomerName(consNo);
			out.println("Welcome "+cname);
			out.println("<h1>Electricity Bill for Consumer Number - "+consNo+"</h1>");
			out.println("<b>Units Consumed:: "+units);
			out.println("<b>Net Amount:: "+net);
		}
		catch(BillException e)
		{
			String errMsg=e.getMessage();
			session.setAttribute("ErrorObj", errMsg);
			rd=request.getRequestDispatcher("ErrorPage");
			rd.forward(request, response);
		}
	}
}
