package com.cg.user.util;

import java.sql.Connection;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.cg.user.exception.BillException;

public class DBUtil {
	public static Connection getCon() throws BillException
	{
		Connection con=null;
		InitialContext context=null;
		try 
		{
			context=new InitialContext();
			DataSource ds= (DataSource)context.lookup("java:/jdbc/OracleDS");
			con=ds.getConnection();
		}
		catch (Exception e) 
		{
			throw new BillException(e.getMessage());
		}
		return con;
	}
}
