package com.cg.corp.dao;

import java.util.List;

import com.cg.corp.dto.FirmMaster;
import com.cg.corp.exception.FirmException;

public interface FirmMasterDao 
{
    List<FirmMaster> getAllData()
    throws FirmException;
    
    FirmMaster getFirmData(long firmId)
    throws FirmException;
    
    long addFirmDetails(FirmMaster firm)
    throws FirmException;
    
}