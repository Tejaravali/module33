package com.cg.corp.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.cg.corp.dto.FirmMaster;
import com.cg.corp.exception.FirmException;
import com.cg.corp.util.DBUtil;


public class FirmMasterDaoImpl 
implements FirmMasterDao
{
    
    Connection con = null;
    PreparedStatement pst = null;
    ResultSet rs = null;
    Statement st = null;

    @Override
    public List<FirmMaster> getAllData() throws FirmException 
    {
        List<FirmMaster> firmList = new ArrayList<FirmMaster>();
        FirmMaster fm;
        try 
        {
            con=DBUtil.getCon();
            st=con.createStatement();
            rs=st.executeQuery(QuerryMapper.SELECT_ALL_FIRMS);
            
            while(rs.next())
            {
                fm = new FirmMaster(rs.getLong("firmId"),rs.getString("owner_name"),
                        rs.getString("business_name"),rs.getString("emailId"),
                        rs.getString("mobileNo"),rs.getString("isActive").charAt(0));
                firmList.add(fm);
            }
        } 
        catch (Exception e)
        {
            throw new FirmException(e.getMessage()); 
            
        }       
       
        
        return firmList;
    }
 /**********************************************************************************/
    
    @Override
    public FirmMaster getFirmData(long firmId) throws FirmException 
    {
        FirmMaster fm = null;
        try
        {
        con = DBUtil.getCon();
        pst = con.prepareStatement(QuerryMapper.SELECT_FIRM);
        pst.setLong(1, firmId);
        rs = pst.executeQuery();
        rs.next();
        fm = new FirmMaster(rs.getLong("firmId"),rs.getString("owner_name"),
                rs.getString("business_name"),rs.getString("emailId"),
                rs.getString("mobileNo"),rs.getString("isActive").charAt(0)); 
        }
        catch(SQLException se)
        {
            throw new FirmException(se.getMessage());
        }
        return fm;
    }

    /********************************************************************************/
    
    @Override
    public long addFirmDetails(FirmMaster fm) throws FirmException 
    {
        
        int dataAdded = 0;
        try
        {
             con=DBUtil.getCon();
             pst=con.prepareStatement(QuerryMapper.INSERT_QUERY);
             fm.setFirmId(generateFirmId());
             
             pst.setLong(1, fm.getFirmId());
             pst.setString(2, fm.getOwner_name());
             pst.setString(3, fm.getBusiness_name());
             pst.setString(4, fm.getEmailId());
             pst.setString(5, fm.getMobileNo());
             pst.setString(6, String.valueOf(fm.getIsActive()));
             
             dataAdded = pst.executeUpdate(); 
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
            throw new FirmException(e.getMessage());
        } 
        
        
        return fm.getFirmId();
    }
    
    /**********************************************************************************/
    
    private long generateFirmId() throws FirmException
    {
        long generatedVal;
        try 
        {
            con=DBUtil.getCon();
            st=con.createStatement();
            rs=st.executeQuery(QuerryMapper.SELECT_SEQUENCE);
            
            rs.next();
            generatedVal=rs.getLong(1);
            
        }
        catch (Exception e) 
        {
            throw new FirmException(e.getMessage());     //exception not handled
        } 
       
        return generatedVal;
    }

}

