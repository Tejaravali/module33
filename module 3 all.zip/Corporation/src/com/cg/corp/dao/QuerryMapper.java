package com.cg.corp.dao;

public interface QuerryMapper 
{
String SELECT_ALL_FIRMS="SELECT * FROM FIRMS_MASTER";
String SELECT_FIRM="SELECT * FROM FIRMS_MASTER WHERE firm_id = ?";
String SELECT_SEQUENCE="Select seq_firm_master.NEXTVAL FROM dual";
String INSERT_QUERY="INSERT INTO FIRMS_MASTER values(?,?,?,?,?,?)";
}
