package com.cg.tb.ctrl;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.tb.Exception.MovieException;
import com.cg.tb.dto.ShowDetails;
import com.cg.tb.service.ShowService;
import com.cg.tb.service.ShowServiceImpl;

/**
 * Servlet implementation class ShowController
 */
@WebServlet(urlPatterns={"/list","/getDetails","/Book"})
public class ShowController extends HttpServlet
{
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ShowController()
	{
		super();
	}

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException 
	{

	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() 
	{

	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		String url=request.getServletPath();
		String targetUrl= "";
		ShowService sSer = new ShowServiceImpl();
		switch(url)
		{
		case "/list":

			try 
			{
				List<ShowDetails> showList;
				showList = sSer.getShowDetails();
				HttpSession session = request.getSession(true);
				session.setAttribute("showList", showList);
				targetUrl="ShowDetails.jsp";
			} 
			catch (MovieException e)
			{
				request.setAttribute("error",e.getMessage());
				targetUrl="Error.jsp";
			}
			break;
		case "/getDetails":

			try
			{
				ShowDetails show;
				String showid = request.getParameter("showid") ;
				show = sSer.getShowDetail(showid);
				request.setAttribute("show", show);
				targetUrl="BookNow.jsp";
			}
			catch (MovieException e) 
			{
				request.setAttribute("error",e.getMessage());
				targetUrl="Error.jsp";
			}
			break;
		case "/Book":

			try
			{

				String showName = request.getParameter("ShowName");
				double price = Double.parseDouble(request.getParameter("Price")) ;
				String customerName = request.getParameter("CustName");
				long mob =Long.parseLong(request.getParameter("MobNo"));
				int availSeats = Integer.parseInt(request.getParameter("SeatsAvail"));
				int noOfSeats = Integer.parseInt(request.getParameter("SeatsBook"));
				if(noOfSeats == 0 || noOfSeats < 0)
				{
					throw new MovieException("Invalid Data");
				}

				if(availSeats < noOfSeats)
				{
					throw new MovieException("Invalid Data");
				}
				else
				{
					int updatedSeats = availSeats-noOfSeats ;
					request.setAttribute("showname", showName);
					request.setAttribute("cname", customerName);
					request.setAttribute("mobileNo", mob);
					request.setAttribute("noOfSeats", noOfSeats);
					double totalPrice = price * noOfSeats ;
					request.setAttribute("totalPrice", totalPrice);
					sSer.updateShowDetails(updatedSeats , showName);
					targetUrl = "Success.jsp" ;
				}
			}
			catch (MovieException e) 
			{
				request.setAttribute("error",e.getMessage());
				targetUrl="Error.jsp";
			}

			break ;
		}

		RequestDispatcher disp=request.getRequestDispatcher(targetUrl);
		disp.forward(request, response);
	}
}


