package com.cg.tb.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import com.cg.tb.Exception.MovieException;
import com.cg.tb.dto.ShowDetails;
import com.cg.tb.util.DBUtil;

public class ShowDaoImpl implements ShowDao
{
	Connection con=null;
	Statement st;
	PreparedStatement pst;
	ResultSet rs;

	@Override
	public List<ShowDetails> getShowDetails() throws MovieException
	{
		
		
		List<ShowDetails> sList = new ArrayList<ShowDetails>();
		try {
			con = DBUtil.getCon();
			st = con.createStatement();
			rs = st.executeQuery("SELECT * FROM ShowDetails");
			
			while (rs.next())
			{
				ShowDetails show = new ShowDetails();
				show.setShowId(rs.getString(1));
				show.setShowName(rs.getString(2));
				show.setLocation(rs.getString(3));
				show.setShowDate(rs.getDate(4));
				show.setAvailableSeats(rs.getInt(5));
				show.setPrice(rs.getDouble(6));
				sList.add(show);
			}
		} 
		catch (SQLException e)
		{
			
			throw new MovieException("Error while fetching showDetails");
		} 
	return sList;
}
	
@Override
public ShowDetails getShowDetail(String showid) throws MovieException 
{
    ShowDetails show = null;
	try 
	{
		con = DBUtil.getCon();
		pst = con.prepareStatement("select * from showdetails where showid=?");
		pst.setString(1, showid);
		rs = pst.executeQuery();
		rs.next();
		show = new ShowDetails();
		show.setShowId(rs.getString(1));
		show.setShowName(rs.getString(2));
		show.setLocation(rs.getString(3));
		show.setShowDate(rs.getDate(4));
		show.setAvailableSeats(rs.getInt(5));
		show.setPrice(rs.getDouble(6));

	} 
	catch (SQLException e) 
	{
	throw new MovieException("Error in obtaining Details");
	}
	return show;
}

	@Override
	public void updateShowDetails(int seats, String showname)
			throws MovieException 
	{
		try
		{
			con = DBUtil.getCon();
			pst = con.prepareStatement("UPDATE ShowDetails SET avseats = ? where showname = ?");
			pst.setInt(1, seats);
			pst.setString(2, showname);
			pst.executeUpdate();
		} 
		catch (SQLException e) 
		{
		
			throw new MovieException("Error in Updating");
		}
	}
}
