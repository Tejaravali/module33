package com.cg.global.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.global.bean.EnquiryBean;
import com.cg.global.exception.ContactBookException;
import com.cg.global.service.ContactBookService;
import com.cg.global.service.ContactBookServiceImpl;


public class Client 
{
	static Scanner sc=null;
	static ContactBookService ser=null;
	
	public static void main(String[] args) 
	{
		ser=new ContactBookServiceImpl();
		sc=new Scanner(System.in);
		int choice=0;
		while(true)
		{
			System.out.println("******Global Recruitments******");
		    System.out.println("Choose an Operation?");
			System.out.println("1.Enter Enquiry Details \t"
					+ " 2.View Enquiry Details on Id \t"
					+ " 0.Exit");

			choice=sc.nextInt();
			switch(choice)
			{
			case 1:
				 addDetails();
				 break;
			/*case 2:
				viewAllDetails();
				break;*/
			
			default:
				System.exit(0);
			}
		}
}
private static void addDetails() 
	{
		System.out.println("Enter First name");
		String fName=sc.next();
		System.out.println("Enter Last Name ");
		String lName=sc.next();
		System.out.println("Enter Contact number");
		String contactNo=sc.next();
		System.out.println("Enter preffered domain");
		String pDomain=sc.next();
		System.out.println("Enter preffered Location");
		String pLocation=sc.next();
		try 
		{
			if(ser.validateFirstName(fName) && ser.validateLastName(lName) && ser.validateContactNo(contactNo) && ser.validatePLocation(pLocation) && ser.validatePDomain(pDomain))
			{
			
				EnquiryBean enq=new EnquiryBean();
				enq.setFname(fName);
				enq.setLname(lName);
				enq.setContactNo(contactNo);
				enq.setpDomain(pDomain);
				enq.setpLocation(pLocation);
				int dataAdded=ser.addEnquiry(enq);
				if(dataAdded==1)
				{
					System.out.println("Employee data added");
				
				}
				else{
					System.out.println("Some exception may be encountered while insertion");

				}
			}
		}
		catch (ContactBookException e) 
		{

			System.out.println(e.getMessage());
		}
		
	}


/*private static void viewAllDetails()
{
    System.out.println("Enter Enquiry id:");
	int eid=sc.nextInt();
	try
	{
		EnquiryBean enq=new EnquiryBean();
		enq.setEnqryId(eid);
		int dataAdded=enq.getEnquiryDetails(eid);
		if(dataAdded==1)
		{
			System.out.println("Data Added:");
		}
		else
		{
			System.out.println("Some Exceptions Occured");
		}
	}   
	catch(ContactBookException e)
	{
		System.out.println("Some Exception while fetching data");
	}
}*/
	
}



