package com.cg.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
     ServletConfig cg=null;
   public RegisterServlet() {
        super();
        
    }

    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        cg=config;
    }

    public void destroy() {
        
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, 

IOException {
        doPost(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, 

IOException {
        String fname=request.getParameter("txtFname");
        String lname=request.getParameter("txtLname");
        String pwd=request.getParameter("txtPwd");
        String gen=request.getParameter("gender");
        String[] skillset = request.getParameterValues("skill");
        String city=request.getParameter("city");
        int length=skillset.length;
        String skills=skillset[0];
        if(length==1)
        {
            skills=skillset[0];
        }
        else
        {
            while(length>1)
            {
                skills=skills+skillset[length-1]+",";
                length=length-1;
            }
        }
        request.setAttribute("First Name", fname);
        request.setAttribute("Last Name", lname);
        request.setAttribute("Password", pwd);
        request.setAttribute("Gender", gen);
        request.setAttribute("Skill Set", skills);
        request.setAttribute("City", city);
        RequestDispatcher rd=request.getRequestDispatcher("/DisplayServlet");
        rd.forward(request, response);
    }

}