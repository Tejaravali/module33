package com.cg.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/DisplayServlet")
public class DisplayServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
       
   public DisplayServlet() {
        super();
        
    }

    public void init(ServletConfig config) throws ServletException {
        
    }

    public void destroy() {
        
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, 

IOException {
        doPost(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, 

IOException {
        String fname=(String) request.getAttribute("First Name");
        String lname=(String) request.getAttribute("Last Name");
        String pwd=(String) request.getAttribute("Password");
        String gender=(String) request.getAttribute("Gender");
        String skillset=(String) request.getAttribute("Skill Set");
        String city=(String) request.getAttribute("City");
        PrintWriter out=response.getWriter();
        out.println("Entered Details are:<br>");
        out.println("First Name :"+fname);
        out.println("<br>Last Name :"+lname);
        out.println("<br>Password :"+pwd);
        out.println("<br>Gender :"+gender);
        out.println("<br>Skill Set :"+skillset);
        out.println("<br>City :"+city);
        
    }

}
