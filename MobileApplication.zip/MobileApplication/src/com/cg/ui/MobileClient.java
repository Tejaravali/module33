package com.cg.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.dto.Mobile;
import com.cg.service.MobileService;
import com.cg.service.MobileServiceImpl;

public class MobileClient
{

	public static void main(String[] args)
	{
		MobileService mser=new MobileServiceImpl();
		int choice;
		Scanner sc=new Scanner(System.in);
		do
		{
			System.out.println("1. Add Mobile:");
			System.out.println("2. Update Mobile:");
			System.out.println("3. Search Mobile:");
			System.out.println("4. Delete Mobile:");
			System.out.println("5. Show All:");
			System.out.println("6.Show Mobiles in price range");
			System.out.println("7. Exit");
			System.out.println("Enter your choice:");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:
				System.out.println("Enter Mobile name:");
				String mname=sc.next();
				System.out.println("Enter Price:");
				double price=sc.nextDouble();
				System.out.println("Enter Quantity:");
				int qty=sc.nextInt();
				Mobile mobile=new Mobile();
				mobile.setMname(mname);
				mobile.setPrice(price);
				mobile.setQty(qty);
				mser.addMobile(mobile);
				System.out.println("Mobile Details Added:");
				break;
			case 2:
				System.out.println("Enter mobile id to search");
				int mid1 = sc.nextInt();
				System.out.println("Enter Mobile name:");
				String mname1=sc.next();
				System.out.println("Enter Price:");
				double price1=sc.nextDouble();
				System.out.println("Enter Quantity:");
				int qty1=sc.nextInt();
				Mobile mobile2=new Mobile();
				mobile2.setMobileId(mid1);
				mobile2.setMname(mname1);
				mobile2.setPrice(price1);
				mobile2.setQty(qty1);
				mser.updateMobile(mobile2);
				System.out.println("Mobile Details Updated:");
				break;
			case 3:
				System.out.println("Enter mobile id to search");
				int mid = sc.nextInt();
				Mobile mobile1=mser.findMobile(mid);
				System.out.println(mobile1);
				break;
			case 4:
				System.out.println("Enter mobile id to delete:");
				int mid2=sc.nextInt();
				Mobile mobile3=mser.findMobile(mid2);
				mser.deleteMobile(mobile3);
				System.out.println("Mobile details Deleted");
				break;
			case 5:
				List<Mobile> mlist=mser.getAllMobiles();
				for(Mobile m:mlist)
				{
					System.out.println(m);
				}
				break;
			case 6:
				System.out.println("Enter minimum price range");
				double minPrice=sc.nextDouble();
				System.out.println("Enter maximum price range");
				double maxPrice=sc.nextDouble();
				List<Mobile> mList1=
					mser.fetchMobileInPriceRange(minPrice, maxPrice);
				for(Mobile m:mList1)
				{
					System.out.println(m);
				}
				break;
			case 7:
				System.exit(0);
				break;
			}
		}while(true);

 
	}

}
