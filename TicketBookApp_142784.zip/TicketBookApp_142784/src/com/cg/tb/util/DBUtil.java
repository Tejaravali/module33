package com.cg.tb.util;
import java.sql.Connection;
import java.sql.SQLException;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import com.cg.tb.Exception.MovieException;


public class DBUtil 
{
	public static Connection getCon() throws MovieException
	{
		Connection con=null;
		InitialContext context;
		try 
		{
			context = new InitialContext();
			DataSource ds=(DataSource)context.lookup
					("java:/jdbc/OracleDS");
			con=ds.getConnection();
		} 
		catch (NamingException e)
		{

			throw new MovieException("Error getting connection:"
					+ e.getMessage());
		}
		catch (SQLException e) 
		{
			throw new MovieException("Error getting connection:"
					+ e.getMessage());
		}
		return con;
	}
}





