package com.cg.mpa.dao;

public interface QueryMapper 
{
String SELECT_ALL_MOBILES = "SELECT mobileid, name, price,quantity FROM mobiles";
String SELECT_MOBILE = "SELECT mobileid,name,price,quantity FROM mobiles WHERE mobileid=?";
String SELECT_SEQUENCE = "SELECT purchase_seq.NEXTVAL FROM dual";
String INSERT_QUERY="INSERT INTO purchasedetails VALUES(?,?,?,?,?,?)";
String UPDATE_QUERY="UPDATE mobiles set quantity=quantity-1 where mobileid=?";
}
