package com.cg.mpa.service;

import java.util.List;

import com.cg.mpa.dao.MobilePurchaseDao;
import com.cg.mpa.dao.MobilePurchaseDaoImpl;
import com.cg.mpa.dto.Mobile;
import com.cg.mpa.dto.PurchaseDetails;
import com.cg.mpa.exception.MobileException;

public class MobileServiceImpl implements MobileService
{
	MobilePurchaseDao mdao = new MobilePurchaseDaoImpl();
	

	@Override
	public List<Mobile> getAllMobiles() throws MobileException
	{
		
		return mdao.getAllMobiles();
	}

	@Override
	public Mobile getMobile(long mid) throws MobileException {
		// TODO Auto-generated method stub
		return mdao.getMobile(mid);
	}

	@Override
	public long insertPurchaseDetails(PurchaseDetails pDetails)
			throws MobileException {
		// TODO Auto-generated method stub
		return mdao.insertPurchaseDetails(pDetails);
	}

	@Override
	public int updateDetails(long mid) throws MobileException
	{
	
		return mdao.updateDetails(mid);
	}

}
