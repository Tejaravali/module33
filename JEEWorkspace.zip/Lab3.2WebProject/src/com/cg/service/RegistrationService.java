package com.cg.service;

public interface RegistrationService {

}
