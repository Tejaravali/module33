package com.cg.tb.service;

import java.util.List;
import com.cg.tb.Exception.MovieException;
import com.cg.tb.dto.ShowDetails;

public interface ShowService 
{
	List<ShowDetails> getShowDetails() throws MovieException ;
	public ShowDetails getShowDetail(String showid) throws MovieException ;
	public void updateShowDetails(int seats , String showname) throws MovieException ;

}
