package com.cg.tb.service;

import java.util.List;

import com.cg.tb.Exception.MovieException;
import com.cg.tb.dao.ShowDao;
import com.cg.tb.dao.ShowDaoImpl;
import com.cg.tb.dto.ShowDetails;

public class ShowServiceImpl implements ShowService
{
	ShowDao sDao = null;
	
	public ShowServiceImpl()
	{
		sDao= new ShowDaoImpl();
	}

	@Override
	public List<ShowDetails> getShowDetails() throws MovieException 
	{
		
		return sDao.getShowDetails();
	}

	@Override
	public ShowDetails getShowDetail(String showid) throws MovieException
	{
		
		return sDao.getShowDetail(showid);
	}

	@Override
	public void updateShowDetails(int seats, String showname)
			throws MovieException 
	{
		 sDao.updateShowDetails(seats, showname);
		
	}

}
