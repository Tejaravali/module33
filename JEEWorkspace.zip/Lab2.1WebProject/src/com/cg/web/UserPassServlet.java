package com.cg.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.regex.Pattern;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/UserPassServlet")
public class UserPassServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
   
    public UserPassServlet() 
    {
        super();
      
    }

	public void init(ServletConfig config) throws ServletException 
	{
	
	}

	public void destroy() 
	{
	
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request,response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		
		PrintWriter pw = response.getWriter();
		if(validate(request,response))
		{
			response.sendRedirect("/Lab2.1WebProject/Success.html");
		}
		else
		{
			response.sendRedirect("/Lab2.1WebProject/Failure.html");
		}
	}

	private boolean validate(HttpServletRequest request,
			HttpServletResponse response)
	{
		String unm=request.getParameter("uname");
		String pwd=request.getParameter("pswd");
		if(unm.equals("ravali")&& pwd.equals("abcd"))
		{
			return true;
		}
		
		return false;
	}

}
