package com.cg.mpa.dao;

public interface QueryMapper
{
	String SELECT_ALL_MOBILES="Select mobileid,name,price,quantity from mobile";
	String SELECT_MOBILE="Select mobileid,name,price,quantity from mobile where mobileid=?";
	String SELECT_SEQUENCE="SELECT pur_seq.NEXTVAL from dual";
	String INSERT_QUERY="INSERT INTO purchasedetails values(?,?,?,?,?,?)";
}
