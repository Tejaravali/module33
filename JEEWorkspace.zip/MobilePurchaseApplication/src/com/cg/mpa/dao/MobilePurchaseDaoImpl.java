package com.cg.mpa.dao;


import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.mpa.Exception.MobileException;
import com.cg.mpa.dto.Mobile;
import com.cg.mpa.dto.PurchaseDetails;

public class MobilePurchaseDaoImpl implements MobilePurchaseDao 
{
	Connection con=null;

	@Override
	public List<Mobile> getAllMobiles() throws MobileException
	{
		List<Mobile>mlist=new ArrayList<>();

		try{
			con=DBUtil.getCon();
			Statement st=con.createStatement();
			ResultSet rst=st.executeQuery(QueryMapper.SELECT_ALL_MOBILES);
			while(rst.next()){
				Mobile m=new Mobile();
				m.setMobileid(rst.getLong("mobileid"));
				m.setMname(rst.getString("name"));
				m.setPrice(rst.getDouble("price"));
				m.setQuantity(rst.getInt("quantity"));
				mlist.add(m);

			}
		}
		catch(SQLException e )
		{
			throw new MobileException("Problem in fetching mobile list"+e.getMessage());
		}
		return mlist;
	}


	@Override
	public Mobile getMobile(long mid) throws MobileException
	{
		Mobile m=null;
		try {

			con=DBUtil.getCon();
			PreparedStatement pst=con.prepareStatement(QueryMapper.SELECT_MOBILE);
			pst.setLong(1, mid);
			ResultSet rst = pst.executeQuery();
			if(rst.next())
			{
				m = new Mobile();
				m.setMobileid(rst.getLong("mobileid"));
				m.setMname(rst.getString("name"));
				m.setPrice(rst.getDouble("price"));
				m.setQuantity(rst.getInt("quantity"));
			}
			else
			{
				throw new MobileException("Mobile Not Found");
			}
		} 
		catch (SQLException e) {

			throw new MobileException("Problem in fetching mobile"+e.getMessage());
		}
		return m;
	}
	private long generatePurchaseId() throws MobileException
	{
		long pid=0;
		try 
		{
			con=DBUtil.getCon();
			Statement st=con.createStatement();
			ResultSet rst=st.executeQuery(QueryMapper.SELECT_SEQUENCE);
			rst.next();
			pid=rst.getLong(1);
			
		} 
		catch (SQLException e)
		{
			throw new MobileException("Problem in generating id:"+e.getMessage());
		}
		return pid;
		
	}

	@Override
	public long insertPurchaseDetails(PurchaseDetails pDetails)
			throws MobileException 
	{
		try {
			con = DBUtil.getCon();
			pDetails.setPurchaseid(generatePurchaseId());
			PreparedStatement pst=con.prepareStatement(QueryMapper.INSERT_QUERY);
			pst.setLong(1, pDetails.getPurchaseid());
			pst.setString(2,pDetails.getCname());
			pst.setString(3,pDetails.getMailid());
			pst.setLong(4,pDetails.getMobileNumber());
			pst.setDate(5, Date.valueOf(pDetails.getPurchaseDate()));
			pst.setLong(6,pDetails.getMobileid());
			pst.executeUpdate();
		} catch (SQLException e) {
			throw new MobileException("Problem in inserting details"+e.getMessage());
		}
		
		return pDetails.getPurchaseid();
	}

}
