package com.cg.mpa.service;

import java.util.List;

import com.cg.mpa.Exception.MobileException;
import com.cg.mpa.dao.MobilePurchaseDao;
import com.cg.mpa.dao.MobilePurchaseDaoImpl;
import com.cg.mpa.dto.Mobile;
import com.cg.mpa.dto.PurchaseDetails;

public class MobileServiceImpl implements MobileService
{
	MobilePurchaseDao mdao=new MobilePurchaseDaoImpl();

	@Override
	public List<Mobile> getAllMobiles() throws MobileException
	{
		return mdao.getAllMobiles();
		
	}

	@Override
	public Mobile getMobile(long mid) throws MobileException 
	{
		return mdao.getMobile(mid);
	}

	@Override
	public long insertPurchaseDetails(PurchaseDetails pDetails)
			throws MobileException
	{
		return mdao.insertPurchaseDetails(pDetails);
	}

}
