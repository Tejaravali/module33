package com.cg.mpa.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.mpa.Exception.MobileException;
import com.cg.mpa.dto.Mobile;
import com.cg.mpa.dto.PurchaseDetails;
import com.cg.mpa.service.MobileService;
import com.cg.mpa.service.MobileServiceImpl;


@WebServlet(urlPatterns={"/home","/buy","/purchase"})
public class PurchaseController extends HttpServlet
{
	private static final long serialVersionUID = 1L;


	public PurchaseController() 
	{
		super();

	}


	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}


	public void destroy()
	{

	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doPost(request,response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String url=request.getServletPath();
		String targetUrl= "";
		MobileService mser=new MobileServiceImpl();
		switch(url)
		{
		case "/home":

			try {
				List<Mobile> mlist;
				mlist = mser.getAllMobiles();
				request.setAttribute("mlist", mlist);
				targetUrl="Home.jsp";
			} 
			catch (MobileException e) 
			{
				request.setAttribute("error",e.getMessage());
				targetUrl="Error.jsp";
			}

			break;
		case "/buy":
			long mid=Long.parseLong(request.getParameter("mid"));
			try
			{
				Mobile mob = mser.getMobile(mid);
				HttpSession sess=request.getSession(true);
				sess.setAttribute("mob", mob);
				targetUrl="Insert.jsp";
			}
			catch(MobileException e)
			{
				request.setAttribute("error",e.getMessage());
				targetUrl="Error.jsp";
			}
			break;
		case "/purchase":
			PurchaseDetails pDetails = new PurchaseDetails();
			pDetails.setCname(request.getParameter("cname"));
			pDetails.setMailid(request.getParameter("mail"));
			pDetails.setMobileNumber(Long.parseLong(request.getParameter("mobilenumber")));
			String dateStr=request.getParameter("pdate");
			DateTimeFormatter format=DateTimeFormatter.ofPattern("yyyy-MM-dd");
			pDetails.setPurchaseDate(LocalDate.parse(dateStr,format));
			HttpSession sess=request.getSession(false);
			Mobile mob=(Mobile)sess.getAttribute("mob");
			pDetails.setMobileid(mob.getMobileid());
			try
			{
				mser.insertPurchaseDetails(pDetails);
				request.setAttribute("pdetail", pDetails);
				targetUrl="Success.jsp";
			}
			catch(MobileException e)
			{
				request.setAttribute("error",e.getMessage());
				targetUrl="Error.jsp";
			}
			break;
		}
		RequestDispatcher disp=request.getRequestDispatcher(targetUrl);
		disp.forward(request, response);
	}

}
