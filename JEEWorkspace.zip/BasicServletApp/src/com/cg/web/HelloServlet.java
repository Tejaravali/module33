package com.cg.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "HelloServletName", urlPatterns = { "/HelloServletMap" })
public class HelloServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public HelloServlet() 
    {
        super();
        System.out.println(" Empty Constructor ");
       
    }

	public void init(ServletConfig config) throws ServletException
	{
		 System.out.println(" Init of Hello Servlet Called ");
	}

	public void destroy() 
	{
		System.out.println(" Destroy of Hello Servlet Called ");
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		PrintWriter out=response.getWriter();
		out.println(
				"<font color=green>"
				+ "<b>Welcome To Capgemini :"
				+ "</b></font>");
	}

}
