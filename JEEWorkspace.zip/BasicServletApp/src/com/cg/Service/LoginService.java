package com.cg.Service;

import java.sql.SQLException;

import com.cg.dto.Login;

public interface LoginService
{
	public Login getUserByUnm(String unm) throws SQLException;

}
