package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.dto.Login;
import com.cg.util.DBUtil;

public class LoginDaoImpl implements LoginDao
{
	Connection con=null;
    PreparedStatement pst=null;
	ResultSet rs =null;
	Login user=null;

	@Override
	public Login getUserByUnm(String unm) throws SQLException
	{
		con=DBUtil.getCon();
		System.out.println(" GOT Connection");
		String qry="SELECT * from user_142784 WHERE user_id=?";
		pst=con.prepareStatement(qry);
		pst.setString(1, unm);
		rs=pst.executeQuery();
		rs.next();
		user=new Login(
				rs.getString("user_id"),
				rs.getString("password"));
		return user;

		
	}
	

}
