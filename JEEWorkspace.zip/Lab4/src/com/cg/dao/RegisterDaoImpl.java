package com.cg.dao;

import java.sql.*;

import com.cg.dto.Register;
import com.cg.util.DBUtil;

public class RegisterDaoImpl implements RegisterDao
{
	Connection con=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	@Override
	public int insertData(Register reg) throws Exception 
	{
		String insertQry="INSERT INTO RegisteredUsers values(?,?,?,?,?,?)";
		int dataAdded=0;
		try{
		con=DBUtil.getCon();
		pst=con.prepareStatement(insertQry);
		pst.setString(1,reg.getFname());
		pst.setString(2,reg.getLname());
		pst.setString(3, reg.getPassword());
		pst.setString(4, reg.getGender());
		pst.setString(5, reg.getSkillSet());
		pst.setString(6, reg.getCity());
		dataAdded=pst.executeUpdate();
		}
		catch(Exception e)
		{
			throw new Exception(e.getMessage());
		}
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				throw new Exception(e.getMessage());
			}	
		}
		return dataAdded;
	}

}
