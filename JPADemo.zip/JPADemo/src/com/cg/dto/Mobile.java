package com.cg.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="mobile")
public class Mobile
{
	@Id
	private int mobileId;
	
	@Column(name="name")
	private String mname;
	
	private double price;
	
	@Column(name="quantity")
	private int qty;
	public int getMobileId() {
		return mobileId;
	}
	public void setMobileId(int mobileId) {
		this.mobileId = mobileId;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	@Override
	public String toString() {
		return "Mobile [mobileId=" + mobileId + ", mname=" + mname + ", price="
				+ price + ", qty=" + qty + "]";
	}
	public Mobile(int mobileId, String mname, double price, int qty) {
		super();
		this.mobileId = mobileId;
		this.mname = mname;
		this.price = price;
		this.qty = qty;
	}
	public Mobile() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}
